 interface PaymentProcessor {
    void processPayment(double amount);
}
  class PaypalPaymentGateway {
	    public void makePayment(double amount) {
	        System.out.println("Processing payment with PayPal: $" + amount);
	    }
	}

 class StripePaymentGateway {
	    public void pay(double amount) {
	        System.out.println("Processing payment with Stripe: $" + amount);
	    }
	}
 class PaypalAdapter implements PaymentProcessor {
	    private final PaypalPaymentGateway paypal;

	    public PaypalAdapter(PaypalPaymentGateway paypal) {
	        this.paypal = paypal;
	    }

	    @Override
	    public void processPayment(double amount) {
	        paypal.makePayment(amount);
	    }
	}
 class StripeAdapter implements PaymentProcessor {
	    private final StripePaymentGateway stripe;

	    public StripeAdapter(StripePaymentGateway stripe) {
	        this.stripe = stripe;
	    }

	    @Override
	    public void processPayment(double amount) {
	        stripe.pay(amount);
	    }
	}


public class Test {
	public static void main(String[] args) {
        PaymentProcessor paypalProcessor = new PaypalAdapter(new PaypalPaymentGateway());
        PaymentProcessor stripeProcessor = new StripeAdapter(new StripePaymentGateway());

        paypalProcessor.processPayment(100.0);
        stripeProcessor.processPayment(200.0);
    }

}
