

interface CustomerRepository{
	String findCustomerById(int id);
}
class CustomerService {
	CustomerRepository cr;
	CustomerService(CustomerRepository cr){
		this.cr=cr;
	}
	public String findCustomerById(int id) {
		
	  return cr.findCustomerById(id);
	}
}

class CustomerRepositoryImpl implements CustomerRepository{
	final int cus_id=101;
	final String cus_name="xyz";
	
	
	public String findCustomerById(int id) {
		return "The customer with Id: "+id+" is "+cus_name;
	}
}

public class main {
	public static void main(String[] args) {
		
		CustomerService cs=new CustomerService(new CustomerRepositoryImpl());
         System.out.println(cs.findCustomerById(101));
         
		}

}